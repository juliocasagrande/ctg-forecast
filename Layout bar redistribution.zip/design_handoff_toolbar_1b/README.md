# Handoff: Barra "SCADAs" — Redistribuição (opção 1b)

## Overview
Redesenho da barra de ferramentas superior da tela "SCADAs" (breadcrumb do documento + controles de revisão/legenda). O layout atual amontoa ~10 controles numa única linha sem hierarquia clara. A opção 1b resolve isso separando a barra em duas fileiras por função: **fileira 1 = identidade do documento** (título, localização, nome, compartilhar), **fileira 2 = controles de visualização** (abas de revisão, importar, legenda de status, caminho crítico, configurações).

## About the Design Files
O arquivo incluso (`Toolbar Redistribution (reference).dc.html`) é uma **referência de design em HTML** — um protótipo mostrando a aparência e distribuição pretendidas, não código de produção para copiar diretamente. A tarefa é recriar esse layout no ambiente/stack real da aplicação (React, Vue, etc.), usando os componentes e padrões já existentes no codebase de produção. Ignore as demais opções (1a, 1c) no arquivo — apenas a seção com `id="1b"` é relevante.

## Fidelity
**Alta fidelidade (hifi)**: cores, tipografia, espaçamento e componentes seguem exatamente o design system CTG.Engenharia (ctg-forecast). Implemente pixel a pixel usando os componentes/classes já existentes no codebase (`.btn`, `.tabs`, `.form-input`, etc. ou seus equivalentes React).

## Layout — opção 1b

Duas fileiras empilhadas, largura total (100% do container da página), sem gap entre elas.

### Fileira 1 — Identidade (altura 52px, fundo `--ctg-navy` #001F5B)
`display:flex; align-items:center; gap:14px; padding:0 20px`
1. Título "SCADAs" — fonte `DM Serif Display`, ~23px (`--text-xl`), peso 700, cor branca.
2. Ícone dropdown (▾) — branco, 16px, ao lado do título (indica seletor de sistema/documento).
3. Ícone editar (✎) — branco a 70% de opacidade, 15px.
4. Divisor vertical — 1px, `rgba(255,255,255,0.18)`, altura total menos ~10px de margem vertical.
5. Pill de localização "📍 ROS SAG e JUR" — fundo `rgba(255,255,255,0.1)`, borda `rgba(255,255,255,0.25)` 1.5px, `border-radius: 6px` (`--radius-sm`), padding `8px 12px`, texto branco 600 (`--text-sm`).
6. Campo de nome "Proposta Comercial" — mesmo estilo do pill acima (fundo/borda translúcidos brancos).
7. Espaçador flexível (`flex:1`) empurra o próximo item para a direita.
8. Botão "↥ Compartilhar" — variante secundária do design system (fundo claro sobre navy, ou `btn-secondary` adaptado a fundo escuro), `border-radius:6px`, padding `8px 16px`, peso 600.

### Fileira 2 — Controles (altura 58px, fundo `--bg-app` #F0F4FA)
`display:flex; align-items:center; gap:14px; padding:0 20px`
1. Abas de revisão — componente `.tabs`/`.tab-btn` do design system: "Rev. 0" (ativa), "Rev. 1", "Rev. 2". Fundo do grupo `--bg-app` mais escuro ou branco conforme token `.tabs` (`background:var(--bg-app); padding:3px; border-radius:10px`), aba ativa com fundo branco + sombra `--shadow-sm` + texto navy.
2. Dropdown "Importar de... ▾" — fundo branco, borda `--border-strong`, `border-radius:6px`, padding `8px 12px`, texto `--text-muted`.
3. Checkbox "Caminho crítico" — checkbox 16x16px borda `--border-strong` + label 600 `--text-sm` cor `--text-secondary`.
4. Espaçador flexível (`flex:1`).
5. Legenda de status (4 itens, gap 16px), cada um: ponto colorido 9px + label 600 `--text-sm`:
   - Concluída → verde `#16A34A`
   - Em andamento → azul `--ctg-blue` (#0070B8)
   - Planejada → navy `--ctg-navy` (#001F5B)
   - Atrasada → vermelho `#DC2626`
6. Divisor vertical 1px `--border-strong`.
7. Botão "⚙ Configurações" — variante primária (`btn-primary`, fundo `--ctg-navy`, texto branco), `border-radius:6px`, padding `8px 16px`.

## Interactions & Behavior
- Abas de revisão: clique troca a revisão ativa (estado local, sem navegação de página).
- Dropdown "Importar de...": abre menu de opções de importação (comportamento existente, não alterado).
- Checkbox "Caminho crítico": alterna destaque do caminho crítico na visualização abaixo da barra (comportamento existente).
- Botões "Compartilhar" e "Configurações": abrem modal/menu existentes — apenas reposicionados nesta opção.
- Hover: botões seguem o padrão do design system (leve escurecimento/clareamento + `translateY(-1px)`); pill/campo de nome não têm interação de hover (apenas leitura/clique para editar, se aplicável no comportamento atual).
- Sem animações novas — mover elementos de posição não introduz motion.

## State Management
Nenhum estado novo é necessário — reaproveita o estado existente da tela (revisão selecionada, filtro de caminho crítico, dados de importação). Esta mudança é puramente de **layout/agrupamento**, não de lógica.

## Design Tokens
- Cores: `--ctg-navy:#001F5B`, `--ctg-blue:#0070B8`, `--bg-app:#F0F4FA`, `--border:rgba(0,31,91,0.1)`, `--border-strong:rgba(0,31,91,0.2)`, status: verde `#16A34A`, vermelho `#DC2626`.
- Tipografia: título em `DM Serif Display` (`--font-display`); todo o resto em `Plus Jakarta Sans` (`--font-body`). Tamanhos: título `--text-xl` (~1.45rem), demais textos `--text-sm` (~0.78rem).
- Raio de borda: `--radius-sm` (6px) em pills, campos, botões, abas internas; `--radius-md` (10px) no container das abas.
- Sombra: `--shadow-sm` na aba ativa.
- Espaçamento: gap de 14px entre grupos na mesma fileira; padding horizontal de 20px nas fileiras; gap de 16px entre itens da legenda.

## Assets
Nenhum asset novo. Ícones usam glifos de texto (▾, ✎) e emoji de localização (📍), consistente com o padrão do design system de usar glifos unicode simples em vez de biblioteca de ícones externa.

## Files
- `Toolbar Redistribution (reference).dc.html` — protótipo HTML completo com as 3 opções exploradas nesta conversa (1a, 1b, 1c). **Implemente apenas a seção `id="1b"`.**
