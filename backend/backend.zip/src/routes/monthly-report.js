import express from 'express';
import multer from 'multer';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth);

// ── Controle de acesso: coordenadores, planejadores e julio ──────────────────
function requireMonthlyReportAccess(req, res, next) {
  const { role, email } = req.user;
  const allowed =
    role === 'admin' ||
    role === 'gestor' ||
    role === 'planejador' ||
    email === 'julio.casagrande@ctgbr.com.br';
  if (!allowed) {
    return res.status(403).json({ error: 'Acesso não autorizado ao relatório de acompanhamento.' });
  }
  next();
}

// ── Upload em memória (sem salvar em disco) ──────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20 MB
  fileFilter: (_, file, cb) => {
    const ok = file.mimetype.includes('spreadsheet') ||
               file.originalname.toLowerCase().endsWith('.xlsx') ||
               file.originalname.toLowerCase().endsWith('.xls');
    ok ? cb(null, true) : cb(new Error('Apenas arquivos Excel são aceitos.'));
  },
});

// ── POST /api/monthly-report/generate ───────────────────────────────────────
router.post(
  '/generate',
  requireMonthlyReportAccess,
  upload.single('excel'),
  async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhum arquivo Excel enviado.' });
    }

    const { mes, ano } = req.body;
    if (!mes || !ano) {
      return res.status(400).json({ error: 'Mês e ano são obrigatórios.' });
    }

    try {
      // Importações dinâmicas (dependências pesadas)
      const XLSX = await import('xlsx');
      const { default: dayjs } = await import('dayjs');

      // ── Leitura do Excel ──────────────────────────────────────────────────
      const wb = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json(ws, { defval: null, raw: false });

      if (!raw.length) {
        return res.status(400).json({ error: 'Planilha vazia ou sem dados.' });
      }

      // ── Normalização de colunas ───────────────────────────────────────────
      function normCol(name) {
        if (!name) return '';
        return name.toString().trim().toLowerCase()
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      }

      const COLMAP = {
        UHE:                  'uhe',
        AREA:                 'area',
        PROJ:                 'projeto/atividade',
        PROJRES:              'projeto',
        FORN:                 'fornecedor',
        GEST:                 'gestor',
        PP:                   'pp/contrato',
        VENC:                 'vencimento',
        VAL_CONTR:            'valor contrato',
        REAL_CONTR:           'realizado contrato',
        SALDO_CONTR:          'saldo contrato',
        VAL_SI:               'valor si',
        REAL_SI:              'realizado si',
        SALDO_SI:             'saldo si',
        RESUMO:               'resumo',
        NAT:                  'natureza',
        EMPRESA:              'empresa',
        REAJUSTES:            'reajustes',
        ADITIVOS:             'aditivos',
        ADITIVO_EM_ANDAMENTO: 'aditivo em andamento',
        CRONOGRAMA:           'cronograma',
      };

      // Mapeia nome normalizado da planilha → chave interna
      const firstRow = raw[0];
      const colKeys = Object.keys(firstRow);
      const resolveMap = {};
      for (const [key, target] of Object.entries(COLMAP)) {
        const found = colKeys.find(c => normCol(c) === target);
        if (found) resolveMap[key] = found;
      }

      function get(row, key) {
        const col = resolveMap[key];
        if (!col) return null;
        const v = row[col];
        return v === null || v === undefined ? null : String(v).trim();
      }

      // ── Helpers ───────────────────────────────────────────────────────────
      function trat(v) {
        if (v === null || v === undefined) return '-';
        const s = String(v).trim();
        return s === '' || s === 'null' || s === 'undefined' ? '-' : s;
      }

      function parseDate(v) {
        if (!v) return null;
        // Excel can give us ISO strings like "2026-03-01T03:00:00.000Z"
        const d = dayjs(v);
        return d.isValid() ? d : null;
      }

      function fmtDateBR(v) {
        const d = parseDate(v);
        return d ? d.format('DD/MM/YYYY') : '-';
      }

      function moneyToFloat(v) {
        if (v === null || v === undefined) return null;
        if (typeof v === 'number') return v;
        const s = String(v).replace('R$', '').replace(/\s/g, '')
          .replace(/\./g, '').replace(',', '.');
        const n = parseFloat(s);
        return isNaN(n) ? null : n;
      }

      function fmtBRL(v) {
        const n = moneyToFloat(v);
        if (n === null) return '-';
        return 'R$ ' + n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }

      function moneyOrRaw(v) {
        if (!v || v === '-') return '-';
        const s = String(v);
        if (/[a-zA-Z+;|]/.test(s) || s.includes('  ')) return s;
        const n = moneyToFloat(s);
        return n !== null ? fmtBRL(n) : s;
      }

      function badgeAditivo(v) {
        const s = trat(v).toUpperCase().replace(/Ã/g, 'A');
        if (s === 'SIM') return "<span class='badge info'>SIM</span>";
        if (s === 'NAO' || s === 'NÃO' || s === 'N') return "<span class='badge success'>NÃO</span>";
        return trat(v);
      }

      function areaClass(area) {
        const a = (area || '').toLowerCase();
        if (a.includes('elétr') || a.includes('eletr')) return 'el';
        if (a.includes('mecân') || a.includes('mecan')) return 'mec';
        if (a.includes('confiab')) return 'con';
        if (a.includes('civil')) return 'civil';
        if (a.includes('automa')) return 'auto';
        return '';
      }

      function saldoClass(siVal, siSaldo) {
        try {
          const sv = parseFloat(siVal) || 0;
          const ss = parseFloat(siSaldo) || 0;
          if (sv <= 0) return '';
          if (ss < 0.1 * sv) return 'warn';
          if (ss < 0.3 * sv) return 'warn2';
        } catch (_) {}
        return '';
      }

      // ── Normaliza linhas ─────────────────────────────────────────────────
      const today = dayjs();
      const lim4m = today.add(120, 'day');
      const lim6m = today.add(180, 'day');
      const lim12m = today.add(365, 'day');

      function dueClass(vencDay) {
        if (!vencDay) return '';
        if (vencDay.isBefore(lim4m)) return 'due-2';
        if (vencDay.isBefore(lim6m)) return 'due-6';
        if (vencDay.isBefore(lim12m)) return 'due-12';
        return '';
      }

      const rows = raw.map(r => ({
        UHE:    trat(get(r, 'UHE')),
        AREA:   trat(get(r, 'AREA')),
        PROJ:   trat(get(r, 'PROJ')),
        PROJRES:trat(get(r, 'PROJRES')),
        FORN:   trat(get(r, 'FORN')),
        GEST:   trat(get(r, 'GEST')),
        PP:     trat(get(r, 'PP')),
        VENC:   get(r, 'VENC'),
        VAL:    get(r, 'VAL_CONTR'),
        REAL:   get(r, 'REAL_CONTR'),
        SALDO:  get(r, 'SALDO_CONTR'),
        SI:     get(r, 'VAL_SI'),
        REALSI: get(r, 'REAL_SI'),
        SALDO_SI: get(r, 'SALDO_SI'),
        RESUMO: trat(get(r, 'RESUMO')),
        NAT:    trat(get(r, 'NAT')),
        EMPRESA:trat(get(r, 'EMPRESA')),
        REAJUSTES: trat(get(r, 'REAJUSTES')),
        ADITIVOS: trat(get(r, 'ADITIVOS')),
        ADITIVO_EM_ANDAMENTO: trat(get(r, 'ADITIVO_EM_ANDAMENTO')),
        CRONOGRAMA: trat(get(r, 'CRONOGRAMA')),
      }));

      // ── Vencimentos < 12 meses ────────────────────────────────────────────
      const prox12 = rows
        .map(r => ({ ...r, _vencDay: parseDate(r.VENC) }))
        .filter(r => r._vencDay && r._vencDay.isBefore(lim12m))
        .sort((a, b) => a._vencDay.valueOf() - b._vencDay.valueOf());

      // ── Agrupamento UHE → Área ────────────────────────────────────────────
      const UHE_ORDER = ['Jurumirim','Salto Grande','Rosana','Canoas 1','Canoas 2',
                         'Garibaldi','Ilha Solteira','Jupiá'];
      const grouped = {};
      for (const r of rows) {
        grouped[r.UHE] = grouped[r.UHE] || {};
        grouped[r.UHE][r.AREA] = grouped[r.UHE][r.AREA] || [];
        grouped[r.UHE][r.AREA].push(r);
      }

      const orderMap = Object.fromEntries(UHE_ORDER.map((u, i) => [u, i]));
      const uheKeys = Object.keys(grouped).sort((a, b) => {
        const ia = orderMap[a] ?? 9999;
        const ib = orderMap[b] ?? 9999;
        return ia !== ib ? ia - ib : a.localeCompare(b);
      });

      const uheOptions = [...new Set(rows.map(r => r.UHE).filter(u => u !== '-'))]
        .sort().map(u => `<option value='${u}'>${u}</option>`).join('\n');
      const areaOptions = [...new Set(rows.map(r => r.AREA).filter(a => a !== '-'))]
        .sort().map(a => `<option value='${a}'>${a}</option>`).join('\n');

      // ── Tabela 12 meses ───────────────────────────────────────────────────
      const table12Rows = prox12.map(r => {
        const dcls = dueClass(r._vencDay);
        return `<tr class='${dcls}' data-kind='row12' data-uhe='${r.UHE}' data-area='${r.AREA}'>
          <td>${r.PP}</td>
          <td>${r.FORN}</td>
          <td>${r.GEST}</td>
          <td>${fmtDateBR(r.VENC)}</td>
          <td>${badgeAditivo(r.ADITIVO_EM_ANDAMENTO)}</td>
        </tr>`;
      }).join('\n');

      // ── Seções por UHE/Área ───────────────────────────────────────────────
      const sections = [];
      for (let ui = 0; ui < uheKeys.length; ui++) {
        const uhe = uheKeys[ui];
        const areaMap = grouped[uhe];
        sections.push(`<section data-kind='uheBlock' data-uhe='${uhe}'>`);
        sections.push(`<h2 class='section-title'>${ui + 1} — ${uhe}</h2>`);

        const areaKeys = Object.keys(areaMap);
        for (let ai = 0; ai < areaKeys.length; ai++) {
          const area = areaKeys[ai];
          const aRows = areaMap[area];
          sections.push(`<section data-kind='areaBlock' data-uhe='${uhe}' data-area='${area}'>`);
          sections.push(`<h3 class='section-title'>${ui + 1}.${ai + 1} — ${area}</h3>`);
          sections.push("<div class='grid'>");

          for (const row of aRows) {
            const clsArea = areaClass(row.AREA);
            const siCls = saldoClass(row.SI, row.SALDO_SI);
            const corBorda = { el: '#0ea5e9', mec: '#f59e0b', con: '#10b981', civil: '#ef4444', auto: '#8b5cf6' }[clsArea] || '#0b5cab';

            sections.push(`
<div class='card ${clsArea}' data-kind="card" data-uhe="${row.UHE}" data-area="${row.AREA}">
  <div class='meta'>
    <span class='pill'><i class='fas fa-landmark'></i> ${row.UHE}</span>
    <span class='pill'><i class='fas fa-tags'></i> ${row.AREA}</span>
    <span class='pill'><i class='fas fa-file-contract'></i> ${row.PP}</span>
    <span class='pill'><i class='fas fa-user-tie'></i> ${row.GEST}</span>
    <span class='pill'><i class='fas fa-industry'></i> ${row.FORN}</span>
    <span class='pill'><i class='fas fa-tag'></i> ${row.NAT}</span>
  </div>
  <h3>${row.PROJ}</h3>
  <p>${row.PROJRES}</p>
  <div class='subcard' style="border:1.5px solid ${corBorda}55; margin-bottom:.5rem;">
    <div class='kv' style="grid-template-columns:160px 1fr;">
      <div class='k'><i class='fas fa-calendar-alt'></i> Vencimento</div>
      <div class='v'>${fmtDateBR(row.VENC)}</div>
    </div>
  </div>
  <div class="cards-4" style="--c1:26fr;--c2:26fr;--c3:24fr;--c4:24fr;">
    <div class='subcard' style="border:1.5px solid ${corBorda}55;">
      <div class='subcard-header'>Contrato</div>
      <div class='kv'>
        <div class='k'><i class='fas fa-dollar-sign'></i> Valor</div>
        <div class='v'>${moneyOrRaw(row.VAL)}</div>
        <div class='k'><i class='fas fa-check-circle'></i> Realizado</div>
        <div class='v'>${moneyOrRaw(row.REAL)}</div>
        <div class='k'><i class='fas fa-balance-scale'></i> Saldo</div>
        <div class='v'>${moneyOrRaw(row.SALDO)}</div>
      </div>
    </div>
    <div class='subcard' style="border:1.5px solid ${corBorda}55;">
      <div class='subcard-header'>SI</div>
      <div class='kv'>
        <div class='k'><i class='fas fa-wallet'></i> Valor</div>
        <div class='v'>${moneyOrRaw(row.SI)}</div>
        <div class='k'><i class='fas fa-check-circle'></i> Realizado</div>
        <div class='v'>${moneyOrRaw(row.REALSI)}</div>
        <div class='k'><i class='fas fa-balance-scale'></i> Saldo</div>
        <div class='v ${siCls}'>${moneyOrRaw(row.SALDO_SI)}</div>
      </div>
    </div>
    <div class='subcard' style="border:1.5px solid ${corBorda}55;">
      <div class='subcard-header'>Reajustes</div>
      <div class='md-content'>${row.REAJUSTES}</div>
    </div>
    <div class='subcard' style="border:1.5px solid ${corBorda}55;">
      <div class='subcard-header'>Aditivos</div>
      <div class='kv'>
        <div class='v'>${badgeAditivo(row.ADITIVOS)}</div>
      </div>
    </div>
  </div>
  <div style="display:grid; grid-template-columns:30fr 50fr; gap:16px; margin-top:.75rem;">
    <div class='subcard' style="border:1.5px solid ${corBorda}55;">
      <div class='subcard-header'><i class='fas fa-calendar'></i> Cronograma</div>
      <div class='md-content'>${row.CRONOGRAMA}</div>
    </div>
    <div class='subcard' style="border:1.5px solid ${corBorda}55;">
      <div class='subcard-header'><i class='fas fa-tasks'></i> Resumo das Atividades</div>
      <div class='md-content'>${row.RESUMO}</div>
    </div>
  </div>
</div>`);
          }

          sections.push('</div></section>');
        }
        sections.push('</section>');
      }

      // ── HTML final ────────────────────────────────────────────────────────
      const mesAno = `${mes} de ${ano}`;
      const html = buildHTML({ mesAno, uheOptions, areaOptions, table12: table12Rows, sections: sections.join('\n') });

      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="Relatorio_Acompanhamento_${mes}_${ano}.html"`);
      res.send(html);

    } catch (err) {
      console.error('[monthly-report] Erro:', err);
      const msg = process.env.NODE_ENV === 'production' ? 'Erro ao processar planilha.' : err.message;
      res.status(500).json({ error: msg });
    }
  }
);

// ── Template HTML ─────────────────────────────────────────────────────────────
function buildHTML({ mesAno, uheOptions, areaOptions, table12, sections }) {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Relatório Mensal — ${mesAno}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" crossorigin="anonymous">
<style>
@page { size: A3 landscape; margin: 5mm; }
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
:root {
  --scale: 0.82; --base: calc(11pt * var(--scale));
  --ink: #0f172a; --muted: #475569; --line: #e2e8f0; --bg: #fff;
  --el: #0ea5e9; --mec: #f59e0b; --con: #10b981; --civil: #ef4444; --auto: #8b5cf6;
  --due2: #fde2e2; --due6: #ffe8c7; --due12: #fffdf0;
}
* { box-sizing: border-box; }
html, body { margin:0; padding:0; background:#fff; color:var(--ink); font:400 var(--base)/1.45 'Inter',system-ui,Arial; }
h1 { font-size:calc(34pt * var(--scale)); margin:0 0 8px; color:#0b5cab; }
h2 { font-size:calc(22pt * var(--scale)); margin:26px 0 12px; }
h3 { font-size:calc(12pt * var(--scale)); margin:8px 0; color:var(--muted); font-weight:600; }
p  { margin:0 0 6px; }
.lead { color:var(--muted); }
.container { margin:0 5mm; }
.section-title { margin:18px 0 10px; padding-bottom:6px; border-bottom:2px solid var(--line); break-after:avoid; }
.cover { height:100vh; display:flex; flex-direction:column; justify-content:center; margin:0 15px; page-break-after:always; }
.shell { display:flex; min-height:100vh; }
.main { flex:1; min-width:0; }
.main .container { margin:0 5mm; }
.sidebar { width:18%; min-width:200px; max-width:320px; border-right:2px solid var(--line); background:#fbfdff; padding:12px; position:sticky; top:0; height:100vh; overflow:auto; transition:width .2s ease,padding .2s ease; }
.sidebar.collapsed { width:36px; min-width:36px; max-width:36px; padding:12px 6px; }
.sidebar.collapsed .sb-top { justify-content:center; }
.sidebar.collapsed .sb-btn { padding:6px 0; width:32px; display:flex; align-items:center; justify-content:center; }
.sidebar.collapsed .sb-title,.sidebar.collapsed .sb-group,.sidebar.collapsed .sb-hint { display:none; }
.sb-top { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:10px; }
.sb-title { font-weight:800; color:#0b5cab; font-size:calc(11pt * var(--scale)); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:flex; align-items:center; gap:8px; }
.sb-btn { border:1px solid var(--line); background:#fff; border-radius:10px; padding:6px 10px; cursor:pointer; color:#0b5cab; }
.sb-group { margin-top:12px; }
.sb-label { font-size:calc(9.5pt * var(--scale)); color:var(--muted); font-weight:700; margin:8px 0 6px; }
.sb-select { width:100%; border:1px solid var(--line); border-radius:10px; padding:8px 10px; background:#fff; font-size:calc(10pt * var(--scale)); }
.sb-clear { width:100%; margin-top:10px; border:1px solid #0b5cab55; background:#0b5cab0d; color:#0b5cab; border-radius:10px; padding:8px 10px; font-weight:700; cursor:pointer; }
.sb-hint { margin-top:10px; color:var(--muted); font-size:calc(9pt * var(--scale)); line-height:1.35; }
.sb-cards { display:grid; gap:10px; }
.sb-card { --sb-accent:#0b5cab; background:#f8fafc; border:1px solid #d1dde8; border-radius:12px; overflow:hidden; box-shadow:0 2px 10px rgba(15,23,42,.05); }
.sb-card-header { display:flex; align-items:center; gap:6px; padding:6px 10px; font-weight:800; font-size:calc(9pt * var(--scale)); color:#0b5cab; background:#e8f2fb; border-bottom:1px solid #d1dde8; }
.sb-card-body { padding:10px 12px 12px; color:var(--muted); font-size:calc(9.2pt * var(--scale)); line-height:1.35; }
table { width:100%; border-collapse:separate; border-spacing:0 6px; }
thead th { text-align:left; font-weight:700; font-size:calc(10pt * var(--scale)); padding:8px 10px; background:#f8fafc; border:1px solid var(--line); border-bottom:2px solid var(--line); }
tbody td { background:#fff; border:1px solid var(--line); padding:8px 10px; font-size:calc(10pt * var(--scale)); }
tr.due-2 td { background:var(--due2) !important; }
tr.due-6 td { background:var(--due6) !important; }
tr.due-12 td { background:var(--due12) !important; }
tr.due-2 td:first-child { border-left:6px solid #ef4444; }
tr.due-6 td:first-child { border-left:6px solid #f59e0b; }
tr.due-12 td:first-child { border-left:6px solid #eab308; }
.legend { background:#f8fafc; border:1px solid var(--line); border-radius:8px; padding:10px 12px; margin-bottom:10px; font-size:calc(9.5pt * var(--scale)); }
.legend-title { font-weight:600; margin-bottom:6px; }
.legend-items { display:flex; gap:14px; flex-wrap:wrap; margin:6px 0; }
.legend-pill { display:inline-block; width:18px; height:10px; border-radius:4px; margin-right:4px; vertical-align:middle; }
.due-2-pill { background:var(--due2); border:1px solid #ef444433; }
.due-6-pill { background:var(--due6); border:1px solid #f59e0b33; }
.due-12-pill { background:var(--due12); border:1px solid #eab30833; }
.grid { display:grid; gap:10px; break-inside:avoid; }
.card { background:var(--bg); border:1px solid var(--line); border-left:6px solid var(--line); border-radius:10px; padding:10px 12px; box-shadow:0 2px 6px rgba(15,23,42,.04); break-inside:avoid; }
.card.el { border-left-color:var(--el); } .card.mec { border-left-color:var(--mec); }
.card.con { border-left-color:var(--con); } .card.civil { border-left-color:var(--civil); }
.card.auto { border-left-color:var(--auto); }
.meta { display:flex; gap:8px; flex-wrap:wrap; margin:4px 0 2px; }
.pill { display:inline-flex; align-items:center; gap:6px; font-size:calc(9pt * var(--scale)); color:var(--muted); background:#f8fafc; border:1px solid var(--line); border-radius:999px; padding:4px 9px; }
.pill i { display:inline-block; width:1.05em; text-align:center; margin-right:.35em; }
.kv { display:grid; grid-template-columns:160px 1fr; column-gap:14px; row-gap:8px; margin:6px 0 4px; align-items:start; }
.kv .k { color:var(--muted); font-weight:600; padding:3px 0; }
.kv .v { padding:3px 0; overflow-wrap:anywhere; word-break:break-word; }
.kv > :nth-child(n+3) { border-top:1px dashed var(--line); }
.subcard { border-radius:8px; padding:.5rem 1rem; }
.subcard-header { font-weight:700; margin-bottom:.5rem; font-size:.95rem; }
.cards-4 { --c1:29fr; --c2:29fr; --c3:24fr; --c4:18fr; display:grid; grid-template-columns:minmax(0,var(--c1)) minmax(0,var(--c2)) minmax(0,var(--c3)) minmax(0,var(--c4)); gap:16px; margin-top:.75rem; width:100%; max-width:100%; min-width:0; align-items:stretch; }
.cards-4 > .subcard { min-width:0; overflow:hidden; }
.warn { color:#b91c1c; } .warn2 { color:#b45309; }
.badge { display:inline-block; padding:4px 10px; border-radius:999px; font-weight:700; font-size:calc(9pt * var(--scale)); border:1px solid var(--line); background:#f8fafc; color:var(--ink); }
.badge.info { background:#0b5cab14; border-color:#0b5cab33; color:#0b5cab; }
.badge.success { background:#10b98114; border-color:#10b98133; color:#0f5132; }
.md-content h1,.md-content h2,.md-content h3 { color:#0b5cab; margin:.5rem 0 .3rem; font-size:calc(10.5pt * var(--scale)); }
.md-content ul,.md-content ol { padding-left:18px; margin:4px 0; }
.md-content li { margin-bottom:4px; line-height:1.4; }
.md-content p { margin:0 0 4px; }
.md-content strong { font-weight:700; } .md-content em { font-style:italic; }
.md-content table { width:100%; border-collapse:collapse; margin-top:6px; font-size:calc(9.5pt * var(--scale)); }
.md-content th,.md-content td { border:1px solid #e2e8f0; padding:5px 8px; text-align:left; }
.md-content th { background:#f8fafc; font-weight:600; }
@media print { .sidebar { display:none !important; } .shell { display:block; } .main .container { margin:0 5mm; } }
</style>
</head>
<body>
<div class='cover'>
  <h1>Relatório Mensal<br>Acompanhamento de Projetos</h1>
  <h2>${mesAno}</h2>
  <h3 class='lead'>Relatório elaborado pela Engenharia de Manutenção</h3>
</div>
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <div class="sb-top">
      <div class="sb-title"><i class="fas fa-filter"></i> Filtros</div>
      <button class="sb-btn" id="sbToggle" title="Recolher/Expandir"><i class="fas fa-filter"></i></button>
    </div>
    <div class="sb-group">
      <div class="sb-label">Usina</div>
      <select class="sb-select" id="filterUHE">
        <option value="">Todas</option>
        ${uheOptions}
      </select>
      <div class="sb-label">Disciplina</div>
      <select class="sb-select" id="filterAREA">
        <option value="">Todas</option>
        ${areaOptions}
      </select>
      <button class="sb-clear" id="clearFilters"><i class="fas fa-eraser"></i> Limpar filtros</button>
    </div>
    <div class="sb-group" id="sbStats">
      <div class="sb-cards">
        <div class="sb-card">
          <div class="sb-card-header"><i class="fas fa-eye"></i> Exibindo</div>
          <div class="sb-card-body"><div id="statsTotal" class="sb-hint"></div></div>
        </div>
        <div class="sb-card">
          <div class="sb-card-header"><i class="fas fa-water"></i> Por Usina</div>
          <div class="sb-card-body"><div id="statsByUHE" class="sb-hint"></div></div>
        </div>
        <div class="sb-card">
          <div class="sb-card-header"><i class="fas fa-tags"></i> Por Disciplina</div>
          <div class="sb-card-body"><div id="statsByAREA" class="sb-hint"></div></div>
        </div>
      </div>
    </div>
  </aside>
  <main class="main">
    <div class='container'>
      <h2 class='section-title'>Introdução e Objetivo</h2>
      <p class='lead'>O objetivo deste relatório é apresentar a situação dos projetos em andamento na área de Engenharia da CTG Brasil. Os dados foram coletados e organizados para manter todos os integrantes atualizados sobre os processos de cada área e usina.</p>
      <h2 class='section-title'>Projetos com Vencimento nos Próximos 12 Meses</h2>
      <div class="legend">
        <div class="legend-title">Legenda de cores:</div>
        <p>Contratos/projetos com vencimento previsto para os próximos 12 meses, ordenados por data.</p>
        <div class="legend-items">
          <span class="legend-pill due-2-pill"></span> Até 4 meses — atenção imediata
          <span class="legend-pill due-6-pill"></span> De 4 a 6 meses — planejamento
          <span class="legend-pill due-12-pill"></span> De 6 a 12 meses — acompanhamento
        </div>
      </div>
      <table>
        <thead><tr><th>PP/CONTRATO</th><th>FORNECEDOR</th><th>GESTOR</th><th>VENCIMENTO</th><th>ADITIVO?</th></tr></thead>
        <tbody>${table12}</tbody>
      </table>
      ${sections}
    </div>
  </main>
</div>
<script>
(function () {
  const sidebar=document.getElementById("sidebar"),sbToggle=document.getElementById("sbToggle"),
    filterUHE=document.getElementById("filterUHE"),filterAREA=document.getElementById("filterAREA"),
    clearBtn=document.getElementById("clearFilters"),statsTotal=document.getElementById("statsTotal"),
    statsByUHE=document.getElementById("statsByUHE"),statsByAREA=document.getElementById("statsByAREA");
  function setCollapsed(v){sidebar?.classList.toggle("collapsed",!!v);}
  function buildCounts(list,attr){const m=new Map();list.forEach(el=>{const k=(el.getAttribute(attr)||"-").trim();m.set(k,(m.get(k)||0)+1);});return m;}
  function mapToHtml(m){return Array.from(m.entries()).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).map(([k,v])=>"• "+k+": <strong>"+v+"</strong>").join("<br>");}
  function updateStats(){const cards=Array.from(document.querySelectorAll("[data-kind='card']")),visible=cards.filter(el=>el.style.display!=="none");if(statsTotal)statsTotal.innerHTML="Exibindo <strong>"+visible.length+"</strong> de <strong>"+cards.length+"</strong> contratos";if(statsByUHE)statsByUHE.innerHTML=visible.length?mapToHtml(buildCounts(visible,"data-uhe")):"-";if(statsByAREA)statsByAREA.innerHTML=visible.length?mapToHtml(buildCounts(visible,"data-area")):"-";}
  function applyFilters(){const uhe=(filterUHE?.value||"").trim(),area=(filterAREA?.value||"").trim();document.querySelectorAll("[data-kind='card']").forEach(el=>{const match=(!uhe||el.getAttribute("data-uhe")===uhe)&&(!area||el.getAttribute("data-area")===area);el.style.display=match?"":"none";});document.querySelectorAll("[data-kind='row12']").forEach(tr=>{const match=(!uhe||tr.getAttribute("data-uhe")===uhe)&&(!area||tr.getAttribute("data-area")===area);tr.style.display=match?"":"none";});document.querySelectorAll("[data-kind='areaBlock']").forEach(sec=>{sec.style.display=sec.querySelector("[data-kind='card']:not([style*='display: none'])")?"":"none";});document.querySelectorAll("[data-kind='uheBlock']").forEach(sec=>{sec.style.display=sec.querySelector("[data-kind='areaBlock']:not([style*='display: none'])")?"":"none";});updateStats();}
  sbToggle?.addEventListener("click",()=>setCollapsed(!sidebar?.classList.contains("collapsed")));
  filterUHE?.addEventListener("change",applyFilters);filterAREA?.addEventListener("change",applyFilters);
  clearBtn?.addEventListener("click",()=>{filterUHE.value="";filterAREA.value="";applyFilters();});
  setCollapsed(true);applyFilters();
})();
</script>
</body>
</html>`;
}

export default router;
